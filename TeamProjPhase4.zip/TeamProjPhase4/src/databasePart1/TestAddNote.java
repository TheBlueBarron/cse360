package databasePart1;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import application.Report;

@SuppressWarnings("unused")
class TestAddNote {
	
	private final static DatabaseHelper databaseHelper = new DatabaseHelper();
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		try {
			databaseHelper.connectToDatabase();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		databaseHelper.deleteReport(100);
	}

	@Test
	void addNote1() {
		if(databaseHelper.addNotes(0, "Note")) {
			fail("**** ERROR **** Valid note on invalid report accepted");
		}
	}
	
	@Test
	void addNote2() {
		if(databaseHelper.addNotes(-1, "Note")) {
			fail("**** ERROR **** Valid note on invalid report accepted");
		}
	}

}
