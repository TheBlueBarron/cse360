package databasePart1;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import application.Report;

class TestAddReport {
	
	private final static DatabaseHelper databaseHelper = new DatabaseHelper();
	
	@BeforeAll
	static void setUp() {
		try {
			databaseHelper.connectToDatabase();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	@AfterAll
	static void breakDown() {
		databaseHelper.deleteReport(100);
	}
	
	@Test
	void add1() {
		Report report1 = new Report(100, "user1", "user2", "report", "");
		if (!databaseHelper.addReport(report1)) {
			fail("**** ERROR **** Valid report was rejected");
		}
	}
	
	@Test
	void add2() {
		Report report2 = null;
		if (databaseHelper.addReport(report2)) {
			fail("**** ERROR **** Invalid report was added");
		}
	}
}
