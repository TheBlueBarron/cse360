package databasePart1;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import application.Report;

@SuppressWarnings("unused")
class TestGetNote {

	private final static DatabaseHelper databaseHelper = new DatabaseHelper();
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		try {
			databaseHelper.connectToDatabase();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
		
	}

	@Test
	void getNote1() {
		if(!(databaseHelper.getNotes(-1) == null)) {
			fail("**** ERROR **** Invalid ID returned some object");
		}
	}
	
	@Test
	void getNote2() {
		if(!(databaseHelper.getNotes(0) == null)) {
			fail("**** ERROR **** Invalid ID returned some object");
		}
	}

}
