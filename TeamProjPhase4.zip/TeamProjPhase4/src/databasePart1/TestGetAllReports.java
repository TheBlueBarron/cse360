package databasePart1;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class TestGetAllReports {
	
	private final static DatabaseHelper databaseHelper = new DatabaseHelper();
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		try {
			databaseHelper.connectToDatabase();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Test
	void getAll1() {
		try {
			if(databaseHelper.getAllReports() == null) {
				fail("**** ERROR **** Valid call resulted in null reference");
			}
		} catch (SQLException e) {
			e.printStackTrace();
			fail("**** ERROR **** Exception thrown");
		}
		
	}

}
