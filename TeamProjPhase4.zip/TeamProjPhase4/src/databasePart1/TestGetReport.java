package databasePart1;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class TestGetReport {
	
	private final static DatabaseHelper databaseHelper = new DatabaseHelper();

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		try {
			databaseHelper.connectToDatabase();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Test
	void get1() {
		if(databaseHelper.getReport(-1) != null) {
			fail("**** ERROR **** Invalid ID fetched some value");
		}
	}
	
	@Test
	void get2() {
		if(databaseHelper.getReport(0) != null) {
			fail("**** ERROR **** Invalid ID fetched some value");
		}
	}
}
