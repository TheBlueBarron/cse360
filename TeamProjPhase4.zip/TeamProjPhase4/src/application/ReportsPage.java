package application;

import java.sql.SQLException;
import java.util.List;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ListView; 

/**
 * <p> Title: Reports Page. </p>
 * 
 * <p> Description: This Java class represents a Reports page for UI purposes in our application. Allows a
 * 					staff member to view all reports existing currently. </p>
 * 
 * @author Jaari Moreno of Wednesday 44 for CSE 360
 */
public class ReportsPage {
	
	private final DatabaseHelper databaseHelper;
	
	private ObservableList<Report> reportsList;
    private ListView<Report> reportsListView;
	
    /**
     * Constructor of the ReportsPage.
     * 
     * @param db		DatabaseHelper object to handle database operations.
     */
	public ReportsPage(DatabaseHelper db) {
		databaseHelper = db;
	}
	
	/**
     * Shows the Reports page.
     * 
     * @param primaryStage	Stage object to display the scene on.
     */
	public void show(Stage primaryStage) {
		// ---------------- Creating Needed UI Elements -----------------
		Label viewReportsLabel = new Label("Viewing Reports");
		VBox mainLayout = new VBox(10);
		mainLayout.setStyle("-fx-alignment: center; -fx-padding: 20;");
		
		reportsListView = new ListView<>();
        reportsListView.setCellFactory(param -> new ListCell<Report>() {
            @Override
            protected void updateItem(Report r, boolean empty) {
                super.updateItem(r, empty);
                if (empty || r == null) {
                    setText(null);
                } else {
                    // Display question ID, text, and author in the list.
                    setText("[" + r.getId() + "] " + r.getBody() + " (against " + r.getOffendingUser() + ")");
                }
            }
        });
        
        Button backButton = new Button("Back");
        Button respondButton = new Button("Respond");
        
        // ----------- Load Data ----------
        loadReports();
		
        // --------------- Button Handlers ---------------
        backButton.setOnAction(e -> {
        	if (DatabaseHelper.cur_user.getUserName().equals("staff")){	
        		new StaffHomePage(databaseHelper).show(primaryStage);
        	} else {
        		new InstructorHomePage(databaseHelper).show(primaryStage);
        	}
        });
        
        respondButton.setOnAction(e -> {
        	Report report = reportsListView.getSelectionModel().getSelectedItem();
        	
        	if (report == null) {
        		showAlert("Error", "Please select a report.");
        		return;
        	} 
	        
        	String ofUser = report.getOffendingUser();
	    	String repUser = report.getReportingUser();
	    	int repId = report.getId();       	
        	
	    	if (DatabaseHelper.cur_user.getUserName().equals("staff")){	
        		new StaffRespondToReportPage(databaseHelper, ofUser, repUser, repId).show(primaryStage);
        	} else {
        		new InstructorRespondToReportPage(databaseHelper, ofUser, repUser, repId).show(primaryStage);
        	}
        });
        
        // ---------- Load Final Display -----------
        mainLayout.getChildren().addAll(viewReportsLabel, reportsListView, respondButton, backButton);
        
        Scene scene = new Scene(mainLayout, 800, 400);

	    // Set the scene to primary stage
	    primaryStage.setScene(scene);
	    primaryStage.show();
	}
	
	/**
	 * Helper method to gather list of all existing reports in the database.
	 */
	private void loadReports() {
        try {
            List<Report> rList = databaseHelper.getAllReports();
            reportsList = FXCollections.observableArrayList(rList);
            reportsListView.setItems(reportsList);
        } catch (SQLException ex) {
            ex.printStackTrace();
            showAlert("Error", "Failed to load reports: " + ex.getMessage());
        }
    }
	
	/******
     * Displays an alert to the UI.
     * 
     * @param title		String of the title to display with the alert.
     * @param message	String of the message to display with the alert.
     */
    private void showAlert(String title, String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(title);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }
}