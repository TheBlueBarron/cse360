package application;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.VBox;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ListView; 
/**
 * <p> Title: Respond To Report Page. </p>
 * 
 * <p> Description: This Java class represents the Respond to Report page in our application, which allows
 * 					a staff role to take appropriate action for reports made against a user. </p>
 * 
 * @author Jaari Moreno of Wednesday 44 for CSE 360
 */
public class InstructorRespondToReportPage {
	
	private final DatabaseHelper databaseHelper;
	private String offendingUser;
	private String reportingUser;
	private int repId;
	
    // Observable list for questions and its ListView for UI display
    private ObservableList<Question> questionsList;
    private ListView<Question> questionsListView;
    // Observable list for answers and its ListView for UI display
    private ObservableList<Answer> answersList;
    private ListView<Answer> answersListView;
    // Observable lists for conversations and their ListViews for UI display;
    // differentiates between offending & reporting user so instructor can see
    // their messages with each party
    private ObservableList<Message> messagesWithOffendingList;
    private ListView<Message> messagesWithOffendingListView;
    
    private ObservableList<Message> messagesWithReportingList;
    private ListView<Message> messagesWithReportingListView;
	
    
    /**
     * Constructor of a new RespondToReportPage. Takes many parameters as this is a page
     * displaying specific information of one user.
     * 
     * @param db			DatabaseHelper object to handle database operations.
     * @param ofUser		String username of offending user, or who the report is against.
     * @param repUser		String username of reporting user, or who created the report.
     * @param repId			Integer ID of the report.
     */
	public InstructorRespondToReportPage(DatabaseHelper db, String ofUser, String repUser, int repId) {
		databaseHelper = db;
		offendingUser = ofUser;
		reportingUser = repUser;
		this.repId = repId;
	}
	
	/**
	 * Shows the RespondToReport page.
	 * 
	 * @param primaryStage		Stage object to display the scene on.
	 */
	public void show(Stage primaryStage) {
		Label respondingToLabel = new Label("Responding to Report");
		VBox mainLayout = new VBox(10);
		mainLayout.setStyle("-fx-alignment: center; -fx-padding: 20;");
		
		// --------------- Create Information Display ------------------
		VBox questionsBox = new VBox();
		Label questionsLabel = new Label("Questions:");
        questionsListView = new ListView<>();
        questionsListView.setCellFactory(param -> new ListCell<Question>() {
            @Override
            protected void updateItem(Question q, boolean empty) {
                super.updateItem(q, empty);
                if (empty || q == null) {
                    setText(null);
                } else {
                    // Display question ID, text, and author in the list.
                    setText("[" + q.getId() + "] " + q.getText() + " (by " + q.getAuthor() + ")");
                }
            }
        });
        questionsBox.getChildren().addAll(questionsLabel, questionsListView);
        
        VBox answersBox = new VBox();
        Label answersLabel = new Label("Answers:");
        answersListView = new ListView<>();
        answersListView.setCellFactory(param -> new ListCell<Answer>() {
            @Override
            protected void updateItem(Answer a, boolean empty) {
                super.updateItem(a, empty);
                if (empty || a == null) {
                    setText(null);
                } else {
                    // Display answer ID, text, and author in the list.
                    setText("[" + a.getId() + "] " + a.getText() + " (by " + a.getAuthor() + ")");
                }
            }
        });
        answersBox.getChildren().addAll(answersLabel, answersListView);
        
        
        VBox messagesBox = new VBox();
        Label messagesWithOffendingLabel = new Label("Messages with offending user: ");
        messagesWithOffendingListView = new ListView<>();
        messagesWithOffendingListView.setCellFactory(param -> new ListCell<Message>() {
            @Override
            protected void updateItem(Message m, boolean empty) {
                super.updateItem(m, empty);
                if (empty || m == null) {
                    setText(null);
                } else {
                    // Display messages
                    setText("[" + m.getId() + "] " + m.getText() + " (sent by " + m.getSenderId() + ")");
                }
            }
        });
        Label messagesWithReportingLabel = new Label("Messages with reporting user: ");
        messagesWithReportingListView = new ListView<>();
        messagesWithReportingListView.setCellFactory(param -> new ListCell<Message>() {
            @Override
            protected void updateItem(Message m, boolean empty) {
                super.updateItem(m, empty);
                if (empty || m == null) {
                    setText(null);
                } else {
                    // Display messages
                    setText("[" + m.getId() + "] " + m.getText() + " (sent by " + m.getSenderId() + ")");
                }
            }
        });
        messagesBox.getChildren().addAll(messagesWithOffendingLabel, messagesWithOffendingListView, 
        								messagesWithReportingLabel, messagesWithReportingListView);
		
        HBox listDisplay = new HBox(10);
        listDisplay.getChildren().addAll(questionsBox, answersBox, messagesBox);
        
        // HBox for operations to perform
        HBox operations = new HBox(10);
        TextField noteField = new TextField("Enter note...");
        Button submitNoteButton = new Button("Submit Note");
        
        operations.getChildren().addAll(noteField, submitNoteButton);
        
        Button backButton = new Button("Back");
        
        // --------------- Load Information ---------------
        loadQuestions(offendingUser);
        loadAnswers(offendingUser);
        loadMessages(offendingUser, reportingUser);
        
        // --------------- Button Handlers ---------------
        backButton.setOnAction(e -> {
        	new ReportsPage(databaseHelper).show(primaryStage);
        });
        
        submitNoteButton.setOnAction(e -> {
        	if (!databaseHelper.getNotes(repId).isEmpty()) {
        		Alert alert = new Alert(AlertType.WARNING, 
        				"The selected report already has a note. Would you like to overwrite it?",
        				ButtonType.YES,
        				ButtonType.NO);
        		Optional<ButtonType> result = alert.showAndWait();
        		if (result.get() == ButtonType.NO) {
        			return;
        		}
        	}
        	
        	String note = noteField.getText();
        	if (note.equals("Enter note...") || note.isEmpty()) {
        		showAlert("Error", "Note cannot be empty!");
        	} else {
        		if (databaseHelper.addNotes(repId, note)) {
        			showAlert("Success", "Note added to report.");
        		} else {
        			showAlert("Error", "Note could not be added.");
        		}
        		new ReportsPage(databaseHelper).show(primaryStage);
        	}	
        });
        
        // ----------- Final Display -----------
        mainLayout.getChildren().addAll(respondingToLabel, listDisplay, operations, backButton);
        
        Scene scene = new Scene(mainLayout, 800, 600);

	    // Set the scene to primary stage
	    primaryStage.setScene(scene);
	    primaryStage.show();
	}
	
    // ---------------- Helper Methods ----------------

	/******
	 * Operation to load the list of questions a particular user
	 * has asked from the database and display in the ListView.
	 * 
	 * @param username	String of the username to use to retrieve corresponding questions.
	 */
    private void loadQuestions(String username) {
        try {
            List<Question> qList = databaseHelper.searchQuestionsByAuthor(username);
            questionsList = FXCollections.observableArrayList(qList);
            questionsListView.setItems(questionsList);
        } catch (SQLException ex) {
            ex.printStackTrace();
            showAlert("Error", "Failed to load questions: " + ex.getMessage());
        }
    }

    /******
     * Operation to load the list of answers a particular question
     * has contributed to the discussion board from the database
     * and display in the ListView.
     * 
     * @param username	String of the username to use to retrieve corresponding answers.
     */
    private void loadAnswers(String username) {
        try {
            List<Answer> aList = databaseHelper.searchAnswersByAuthor(username);
            answersList = FXCollections.observableArrayList(aList);
            answersListView.setItems(answersList);
        } catch (SQLException ex) {
            ex.printStackTrace();
            showAlert("Error", "Failed to load answers: " + ex.getMessage());
        }
    }
    
    /******
     * Operation to load a list of messages sent between two particular users
     * of the discussion board for moderator review.
     * 
     * @param username1	String of the first username to use to retrieve corresponding messages.
     * @param username2	String of the second username to use to retrieve corresponding messages.
     */
    private void loadMessages(String offending, String reporting) {
        try {
            Conversations conversation1 = databaseHelper.getSpecificConversation(offending, DatabaseHelper.cur_user.getUserName());
            List<Message> mList1 = databaseHelper.getMessagesForConversation(conversation1.getId());
            messagesWithOffendingList = FXCollections.observableArrayList(mList1);
            messagesWithOffendingListView.setItems(messagesWithOffendingList);
            
            Conversations conversation2 = databaseHelper.getSpecificConversation(reporting, DatabaseHelper.cur_user.getUserName());
            List<Message> mList2 = databaseHelper.getMessagesForConversation(conversation2.getId());
            messagesWithReportingList = FXCollections.observableArrayList(mList2);
            messagesWithReportingListView.setItems(messagesWithReportingList);
        } catch (SQLException ex) {
            ex.printStackTrace();
            showAlert("Error", "Failed to load answers: " + ex.getMessage());
        }
    }
	
	/******
     * Displays an alert to the UI.
     * 
     * @param title		String of the title to display with the alert.
     * @param message	String of the message to display with the alert.
     */
    private void showAlert(String title, String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(title);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }
}