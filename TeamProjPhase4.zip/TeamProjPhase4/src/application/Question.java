package application;

/**
 * <p> Title: Reports Page. </p>
 * 
 * <p> Description: This Java class represents a Question object in the application. </p>
 * 
 * @author Wednesday 44 of CSE 360
 */
public class Question {
    // Unique ID for the question
    private int id;
    // The actual text of the question
    private String text;
    // Who asked the question
    private String author;
    // You can see if the question is resolved
    private boolean isResolved;
    // See if a question is flagged for review
    private boolean flagged;

    /** 
     * Constructor that takes an id, text, author, isResolved, and isFlagged. 
     * It throws an error if the question text is empty.
     * 
     * @param id			Integer ID of Question.
     * @param text			String body of Question.
     * @param author		String author of Question.
     * @param isResolved	Boolean flag that marks if question is resolved.
     * @param isFlagged		Boolean flag that marks if question is flagged for review.
     */
    public Question(int id, String text, String author, boolean isResolved, boolean isFlagged) {
        if (!isValidQuestionText(text)) {
            throw new IllegalArgumentException("Question text cannot be empty.");
        }
        this.id = id;
        this.text = text;
        this.author = author;
        this.isResolved = isResolved;
        this.flagged = isFlagged;
    }
    
    /** 
     * Constructor for creating a new question when we don't have an ID yet.
     * The database will assign the ID later.
     * 
     * @param text			String body of Question.
     * @param author		String author of Question.
     * @param isResolved	Boolean flag that marks if question is resolved.
     * @param isFlagged		Boolean flag that marks if question is flagged for review.
     */

    public Question(String text, String author, boolean isResolved, boolean isFlagged) {
        this(-1, text, author, isResolved, isFlagged);
    }

    /** 
     * Checks if the question text is valid (not null or blank)
     * 
     * @param text	Text to check.
     * @return		Returns true if valid.
     */
    public static boolean isValidQuestionText(String text) {
        return text != null && !text.trim().isEmpty();
    }
    
    /** 
     * Getter for the question ID
     * 
     * @return Integer ID.
     */
    public int getId() {
        return id;
    }
    
    /** 
     * Setter for the question ID
     * 
     * @param id	Integer ID.
     */
    public void setId(int id) { 
        this.id = id; 
    }
    
    /** 
     * Getter for the question text
     * @return Question text.
     */
    public String getText() {
        return text;
    }
    /** 
     * Getter for resolved flag
     * @return Boolean of isResolved flag.
     */
    public boolean getIsResolved() {
    	return isResolved;
    }
    /**
     * Setter for resolved flag.
     */
    public void markAsResolved() {
    	isResolved = true;
    }
    
	/** 
	 * Getter for review flag.
	 * @return		Boolean of isFlagged flag.
	 */
	public boolean getFlagged() {
		return flagged;
	}
	/** 
	 * Setter for review flag.
	 */
	public void markAsFlagged() {
		flagged = true;
	}
    
    /** 
     * Setter for the question text; validates before setting
     * @param text		Text to change body to.
     */
    public void setText(String text) {
        if (!isValidQuestionText(text)) {
            throw new IllegalArgumentException("Question text cannot be empty.");
        }
        this.text = text;
    }
    
    /** 
     * Getter for the author of the question
     * @return		Returns String of author of Question.
     */
    public String getAuthor() {
        return author;
    }
    
    /** 
     * Overridden toString method to print out question details easily
     * 
     * @return String of formatted question.
     */
    @Override
    public String toString() {
        return "Question [id=" + id + ", text=" + text + ", author=" + author + "]";
    }
}
