package databasePart1;

import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import application.Report;

@SuppressWarnings("unused")
class TestDeleteReport {

	private final static DatabaseHelper databaseHelper = new DatabaseHelper();
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
		try {
			databaseHelper.connectToDatabase();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	@Test
	void delete1() {
		if(databaseHelper.deleteReport(-1)) {
			fail("**** ERROR **** Invalid ID was not rejected");
		}
	}
	
	@Test
	void delete2() {
		if (databaseHelper.deleteReport(0)) {
			fail("**** ERROR **** Invalid ID was not rejected");
		}
	}
}
