package application;

import databasePart1.DatabaseHelper;
import javafx.application.Platform; 
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.scene.Scene; 
import javafx.scene.control.Alert; 
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox; 
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage; 
import java.sql.SQLException;

/**
 * <p> Title: Create Report Page. </p>
 * 
 * <p> Description: This Java class represents the CreateReportPage for UI purposes. Allows for creation of a report
 * 					against a user. </p>
 * 
 * @author Jaari Moreno of Wednesday 44 for CSE 360
 */
public class CreateReportPage {
	
	private final DatabaseHelper db;
	private String offendingUser;
	
	/**
	 * Constructor to create a new CreateReportpage.
	 * 
	 * @param db	DatabaseHelper object to handle database operations.
	 */
	public CreateReportPage(DatabaseHelper db) {
		this.db = db;
		offendingUser = "";
	}
	
	/**
	 * Constructor to create a new CreateReportPage against a specific user.
	 * 
	 * @param db				DatabaseHelper object to handle database operations.
	 * @param offendingUser		String username of user who the report is against.
	 */
	public CreateReportPage(DatabaseHelper db, String offendingUser) {
		this.db = db;
		this.offendingUser = offendingUser;
	}
	
	/**
     * Shows the CreateReportPage.
     * 
     * @param primaryStage	Stage object to display the scene on.
     */
	public void show(Stage primaryStage) {
		Label createReportLabel = new Label("Create a Report");
		Label offendingUserLabel = new Label("Reporting user: " + this.offendingUser);
		TextField offendingUserField = new TextField("Enter user to report...");
		TextField reportBodyField = new TextField("Enter report...");
		
		// ---------------- Main Layout ----------------
        // Create a vertical box as the main container with some spacing and padding.
        VBox mainLayout = new VBox(10);
        mainLayout.setPadding(new Insets(10));

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> {
        	new DiscussionPage(db).show(primaryStage);
        });
        
        Button submitReportButton = new Button("Submit Report");
        submitReportButton.setOnAction(e -> {
        	String body = reportBodyField.getText();
        	if (body.equals("Enter report...") || body.isEmpty()) {
    			showAlert("Error", "Body cannot be empty!");
    		} else {
    			if (offendingUser.isEmpty()) {
            		String offendingUser = offendingUserField.getText();
            		if (offendingUser.equals("Enter user to report...") || offendingUser.isEmpty()) {
            			showAlert("Error", "Please enter a user to report.");
            		} else {
            			Report report = new Report(0, DatabaseHelper.cur_user.getUserName(), offendingUser, body, "");
            			if (db.addReport(report)) {
            				showAlert("Success", "Report submitted!");
            			} else {
            				showAlert("Error", "Report was not submitted.");
            			}
            		}
            	} else {
            		Report report = new Report(0, DatabaseHelper.cur_user.getUserName(), this.offendingUser, body, "");
        			if (db.addReport(report)) {
        				showAlert("Success", "Report submitted!");
        			} else {
        				showAlert("Error", "Report was not submitted.");
        			}
            	}
    		}
        });
        
        if (offendingUser.isEmpty()) {
        	mainLayout.getChildren().addAll(createReportLabel, offendingUserField, 
        			reportBodyField, submitReportButton, backButton);
        } else {
        	mainLayout.getChildren().addAll(createReportLabel, offendingUserLabel, 
        			reportBodyField, submitReportButton, backButton);
        }
        

		Scene scene = new Scene(mainLayout, 800, 400);
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	/******
     * Displays an alert to the UI.
     * 
     * @param title		String of the title to display with the alert.
     * @param message	String of the message to display with the alert.
     */
    private void showAlert(String title, String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(title);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }
}