package application;

/**
 * <p> Title: Report. </p>
 * 
 * <p> Description: This Java class represents a Report object made within the application. </p>
 * 
 * @author Jaari Moreno of Wednesday 44 for CSE 360
 */
public class Report {
	private int id;
	private String reportingUser;
	private String offendingUser;
	private String body;
	private String notes;
	
	/**
	 * Constructor of a default Report object with no given values.
	 */
	public Report() {
		this.id = 0;
		this.reportingUser = "";
		this.offendingUser = "";
		this.body = "";
		this.notes = "";
	}
	
	/**
	 * Constructor of a Report object with given values.
	 * 
	 * @param id				Integer ID of the report.
	 * @param reportingUser		String username of the user who created the report.
	 * @param offendingUser		String username of the user who the report is against.
	 * @param body				String body of the report.
	 * @param notes				String notes attached to the report.
	 */
	public Report(int id, String reportingUser, String offendingUser, String body, String notes) {
		this.id = id;
		this.reportingUser = reportingUser;
		this.offendingUser = offendingUser;
		this.body = body;
		this.notes = "";
	}
	
	/**
	 * Returns ID of report.
	 * 
	 * @return		Integer ID of report.
	 */
	public int getId() {
		return this.id;
	}
	
	/**
	 * Returns username of the user that created the report.
	 * 
	 * @return		String username of the user that created the report.
	 */
	public String getReportingUser() {
		return this.reportingUser;
	}
	
	/**
	 * Returns username of the user that the report is against.
	 * 
	 * @return		String username of the user that the report is against.
	 */
	public String getOffendingUser() {
		return this.offendingUser;
	}
	
	/**
	 * Returns body of the report.
	 * 
	 * @return		String body of the report.
	 */
	public String getBody() {
		return this.body;
	}
	
	/**
	 * Returns notes of the report.
	 * 
	 * @return		String notes attached to the report.
	 */
	public String getNotes() {
		return this.notes;
	}
	
	/**
	 * Sets report ID.
	 * 
	 * @param id		Integer ID of the report.
	 */
	public void setId(int id) {
		this.id = id;
	}
	
	/**
	 * Sets reporting user by username after checking validity.
	 * 
	 * @param user		String username of the reporting user.
	 */
	public void setReportingUser(String user) {
		if (isValidText(user)) { this.reportingUser = user; }
	}
	
	/**
	 * Sets offending user by username after checking validity.
	 * 
	 * @param user		String username of the offending user.
	 */
	public void setOffendingUser(String user) {
		if (isValidText(user)) { this.offendingUser = user; }
	}
	
	/**
	 * Sets body of a report after checking validity.
	 * 
	 * @param body		String body of the report.
	 */
	public void setBody(String body) {
		if (isValidText(body)) { this.body = body; }
	}
	
	/**
	 * Sets notes of a report after checking validity.
	 * 
	 * @param notes		String notes to attach to the report.
	 */
	public void setNotes(String notes) {
		if (isValidText(notes)) { this.notes = notes; }
	}
	
	/**
	 * Overridden {@code toString} method to easily format reports.
	 */
	@Override
    public String toString() {
        return "Report [id=" + id + ", reportingUser=" + reportingUser + 
        		", offendingUser=" + offendingUser + ", body=" + body + "]";
    }
	
	/**
	 * Helper method to check validity of given text.
	 * 
	 * @param text		String text to check.
	 * @return			Returns true if text is non-empty and non-null.
	 */
	public static boolean isValidText(String text) {
        return text != null && !text.trim().isEmpty();
    }
}