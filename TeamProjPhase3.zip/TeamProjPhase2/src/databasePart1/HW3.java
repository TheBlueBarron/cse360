package databasePart1;

import java.sql.SQLException;
import application.Answer;
import application.Question;

/******
 * <p> Title: HW3 Automated Testing Class. </p>
 * 
 * <p> Description: Java class to test some of the functionalities for TP2 of CSE360. </p>
 * 
 * @author Wednesday 44 of CSE 360, modifications and mainline by Jaari Moreno
 * 
*/
public class HW3 {

	static int numPassed = 0;
	static int numFailed = 0;
	
	/***
	 * This mainline connects to the database, runs each of the included tests, and 
	 * prints a footer with the results of the testing.
	*/
	public static void main(String[] args) {
		DatabaseHelper db = new DatabaseHelper();
		try {
			// Connect to database
			db.connectToDatabase();
			
			// Run invalid question deletion test
			testDeleteQuestionInvalid(db);
			// Run valid answer creation test
			testCreateAnswerValid(db);
			// Run invalid answer creation test
			testCreateAnswerInvalid(db);
			
			// Create new Question object for use in testing
			Question q1 = new Question(1, "Asking questions?", "Quincy", false);
			db.addQuestion(q1);
			// These tests should pass
			testIsResolvedQuestion(db, q1.getId(), q1.getIsResolved(), false);
			testIsResolvedQuestion(db, q1.getId(), true, true);
			// This test will fail, but is intended to show the functionality
			testIsResolvedQuestion(db, q1.getId(), q1.getIsResolved(), false);
			
			// Create new Answer object for use in testing
			Answer a1 = new Answer(1, q1.getId(), "Yes, actually!", "Annie", false);
			db.addAnswer(a1);
			// These tests should pass
			testIsResolvedAnswer(db, a1.getId(), a1.getResolved(), false);
			testIsResolvedAnswer(db, a1.getId(), true, true);
			// This test will fail, but is intended to show the functionality
			testIsResolvedAnswer(db, a1.getId(), a1.getResolved(), false);
			
			// Print footer
			System.out.println("___________________________________________________________________");
			System.out.println("Number of tests passed: " + numPassed);
			System.out.println("Number of tests failed: " + numFailed);
			
		} catch (SQLException e) {
			// If any errors happen in the database/testing phases, catch and print such
			System.out.println("****ERROR****");
			System.out.println("Exception passed from connection or one of the tests!");
		}
	}
	
	/** 
	 * Automated test of the database that checks whether an invalid question
	 * (one that doesn't exist in the database) can be deleted. Prints either pass/fail.
	 * 
	 * @param db	a DatabaseHelper object that provides connection to database
	 *
	 */
    private static void testDeleteQuestionInvalid(DatabaseHelper db) {
        /* Print test header */
    	System.out.println("___________________________________________________________________");
        System.out.println("Test: DELETE a question with invalid ID (does not exist)");
        try {
        	/* Attempt to delete question with an invalid ID; -999 does not exist in the database*/
            boolean result = db.deleteQuestion(-999);
            if (!result) {
            	/* If the database returns that it could not be deleted, this test passes */
                System.out.println("PASS: Attempting to delete a non-existent question returned false.");
                numPassed++;
            } else {
            	/* If something was able to be deleted by the database, this test fails */
                System.out.println("FAIL: Non-existent question deletion returned true.");
                numFailed++;
            }
        } catch (SQLException e) {
        	/* Catch any exceptions thrown by the database; will count as a fail */
            System.out.println("FAIL: Exception while deleting non-existent question: " + e.getMessage());
            numFailed++;
        }
    }
    
    /** 
	 * Automated test that checks whether an answer with valid parameters can be
	 * added to the database. Creates a Question object and corresponding Answer
	 * object internally to do this. Prints either pass/fail.
	 * 
	 * @param db	a DatabaseHelper object that provides connection to database
	 *
	 */
    private static void testCreateAnswerValid(DatabaseHelper db) {
    	/* Print test header */
        System.out.println("___________________________________________________________________");
        System.out.println("Test: Create a VALID answer");
        /* Create a question first to associate with the answer */
        Question q = new Question("Should this be tested?", "Frank", false);
        try {
            db.addQuestion(q);
            /* Create answer to associate with question & add to database*/
            Answer a = new Answer(q.getId(), "Yes!", "Jim", false);
            db.addAnswer(a);
        	/* If an answer was created with a valid ID, the test passes. If not, it fails */
            if (a.getId() > 0) {
                System.out.println("PASS: Valid answer created with ID " + a.getId());
                numPassed++;
            } else {
                System.out.println("FAIL: Valid answer did not receive a valid ID.");
                numFailed++;
            }
        } catch (SQLException e) {
        	/* If an SQLException is caught, that means the answer couldn't be added and the test fails. */
            System.out.println("FAIL: Exception while creating a valid answer: " + e.getMessage());
            numFailed++;
        } catch (IllegalArgumentException e) {
        	/* If an IllegalArgumentException is caught, that means the answer, although valid, was rejected 
        	 * by the constructor and the test fails. */
            System.out.println("FAIL: Unexpected IllegalArgumentException for a valid answer text.");
            numFailed++;
        }
    }
    
    /** 
	 * Automated test that checks whether an Answer object with illegal parameters
	 * can be created, such as with empty Strings or mismatched parameters. Creates
	 * a Question object and Answer object internally to do this. Prints either pass/fail.
	 * 
	 * @param db	a DatabaseHelper object that provides connection to database
	 *
	 */
    private static void testCreateAnswerInvalid(DatabaseHelper db) {
        /* Print test header */
    	System.out.println("___________________________________________________________________");
        System.out.println("Test: Create an INVALID answer (empty text)");
        /* Create a question to associate with the answer */
        Question q = new Question("Question for invalid answer", "Hank", false);
        try {
        	/* Add question to database */
            db.addQuestion(q);
            /* Create new answer to associate with question & attempt to add to database */
            Answer a = new Answer(q.getId(), "", "Ian", false);
            db.addAnswer(a);
            /* If test gets to this point, that means no error was caught, which is incorrect. */
            System.out.println("FAIL: Invalid answer was created without error.");
            numFailed++;
        } catch (IllegalArgumentException e) {
        	/* If the answer gets rejected by the constructor, the test passes. */
            System.out.println("PASS: Caught expected IllegalArgumentException for empty answer text.");
            numPassed++;
        } catch (SQLException e) {
        	/* If the answer was attempted to be added to the database, the test fails. */
            System.out.println("FAIL: Caught SQLException instead of IllegalArgumentException: " + e.getMessage());
            numFailed++;
        }
    }
    
    /** 
	 * Automated test that checks whether an already existing Question in the database
	 * can have its isResolved flag modified. Prints either pass/fail.
	 * 
	 * @param db			a DatabaseHelper object that provides connection to database
	 * @param id			integer ID of the Question to check
	 * @param resolved		Boolean to set isResolved flag as
	 * @param expectedAns	Boolean of whether the test was expected to pass or fail
	 * @throws				SQLException from database
	 *
	 */
    private static void testIsResolvedQuestion(DatabaseHelper db, int id, boolean resolved, boolean expectedAns) throws SQLException {
    	/* Print test header */
    	System.out.println("___________________________________________________________________");
        System.out.println("Test: Update question isResolved flag");
    	/* Create a Question object given the ID param */
    	Question q = db.getQuestionById(id);
        if (q == null) {
        	/* Check if question ID exists in database */
            System.out.println("\n*** " + (!expectedAns ? "PASS" : "FAIL") + " ***");
            System.out.println("Question ID does not exist");
            if (!expectedAns) { numPassed++; } else { numFailed++; }
            return;
        } else if (q.getIsResolved() == resolved) {
        	/* If a question already has the desired resolved param, check whether the test was expected to
        	 * pass or fail; if it was expected to pass, then this would be a fail, as it could not be updated */
            System.out.println("\n*** " + (!expectedAns ? "PASS" : "FAIL") + " ***");
            System.out.println("isResolved is already \"" + resolved + "\"");
            if (!expectedAns) { numPassed++; } else { numFailed++; }
            return;
        } else {
        	/* If a question does not already have the desired resolved param, the test will create a new Question object
        	 * to display the new isResolved value and print the result */
            db.updateIsResolvedQuestion(id, resolved);
            Question q1 = db.getQuestionById(id);
            if (expectedAns) {
            	/* If expected to change, print the change */
            	System.out.println("\n*** PASS ***");
                System.out.println("Question \"" + q.getText() + "\"");
                System.out.println("isResolved changed from \"" + q.getIsResolved() + "\" to \"" + q1.getIsResolved() + "\"");
                numPassed++;
            } else {
            	/* If not expected to change, print as such */ 
            	System.out.println("\n*** FAIL ***");
            	System.out.println("Answer \"" + q.getText() + "\"");
            	System.out.println("isResolved changed from \"" + q.getIsResolved() + "\" to \"" + q1.getIsResolved() + "\"");
            	System.out.println("Expected no change");
            	numFailed++;
            }
            
        }
    }
    
    /** 
	 * Automated test that checks whether an already existing Answer in the database
	 * can have its isResolved flag modified. Prints either pass/fail.
	 * 
	 * @param db			a DatabaseHelper object that provides connection to database
	 * @param id			integer ID of the Answer to check
	 * @param resolved		Boolean to set isResolved flag as
	 * @param expectedAns	Boolean of whether the test was expected to pass or fail
	 * @throws				SQLException from database
	 *
	 */
    private static void testIsResolvedAnswer(DatabaseHelper db, int id, boolean resolved, boolean expectedAns) throws SQLException {
    	/* Print test header */
    	System.out.println("___________________________________________________________________");
        System.out.println("Test: Update question isResolved flag");
    	/* Create a new Answer object given the ID param */
    	Answer a = db.getAnswerById(id);
        if (a == null) {
        	/* Check if answer ID exists in database */
            System.out.println("\n*** " + (!expectedAns ? "PASS" : "FAIL") + " ***");
            System.out.println("Answer ID does not exist");
            if (!expectedAns) { numPassed++; } else { numFailed++; }
            return;
        } else if (a.getResolved() == resolved) {
        	/* If an answer already has the desired resolved param, check whether the test was expected to
        	 * pass or fail; if it was expected to pass, then this would be a fail, as it could not be updated */
            System.out.println("\n*** " + (!expectedAns ? "PASS" : "FAIL") + " ***");
            System.out.println("isResolved is already \"" + resolved + "\"");
            if (!expectedAns) { numPassed++; } else { numFailed++; }
            return;
        } else {
        	/* If an answer does not already have the desired resolved param, the test will create a new Answer object
        	 * to display the new isResolved value and print the result */
            db.updateAnswerResolved(id, resolved);
            Answer a1 = db.getAnswerById(id);
            if (expectedAns) {
            	/* If expected to change, print the change */
            	System.out.println("\n*** PASS ***");
                System.out.println("Answer \"" + a.getText() + "\"");
                System.out.println("isResolved changed from \"" + a.getResolved() + "\" to \"" + a1.getResolved() + "\"");
                numPassed++;
            } else {
            	/* If not expected to change, print as such */ 
            	System.out.println("\n*** FAIL ***");
            	System.out.println("Answer \"" + a.getText() + "\"");
            	System.out.println("isResolved changed from \"" + a.getResolved() + "\" to \"" + a1.getResolved() + "\"");
            	System.out.println("Expected no change");
            	numFailed++;
            }
        }
    }
}
